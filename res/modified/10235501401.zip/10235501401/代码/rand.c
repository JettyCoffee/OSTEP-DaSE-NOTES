#include "types.h"
#include "defs.h"
// 线性同余伪随机数生成器
unsigned int random_at_most(unsigned int max) {
  static unsigned int seed = 1;
  seed = (seed * 1103515245 + 12345) & 0x7fffffff;
  return seed % (max + 1);}
