#include "types.h"
#include "user.h"
#include "pstat.h"
int main() {
  struct pstat ps;
  if(getpinfo(&ps) < 0) {
    printf(2, "getpinfo failed\n");
    exit();
  }
printf(1, "PID\tInuse\tTickets\tTicks\tRatio\n");
int total = 0;
for(int i=0; i<NPROC; i++) 
  if(ps.inuse[i]) total += ps.ticks[i];
for(int i=0; i<NPROC; i++) {
  if(ps.inuse[i]) {
    int ratio = total > 0 ? (ps.ticks[i]*100)/total : 0;
    printf(1, "%d\t%d\t%d\t%d\t%d%%\n", 
      ps.pid[i], ps.inuse[i], ps.tickets[i], ps.ticks[i], ratio);
  }
}
  exit();
}
