unsigned int random_at_most(unsigned int max);
