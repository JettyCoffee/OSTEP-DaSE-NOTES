#ifndef _PSTAT_H_
#define _PSTAT_H_
#define NPROC 64
struct pstat {
    int inuse[NPROC];
    int tickets[NPROC];
    int pid[NPROC];
    int ticks[NPROC];
};
#endif 
