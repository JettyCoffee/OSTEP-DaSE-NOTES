#include "types.h"
#include "user.h"
int main(int argc, char *argv[]) {
    if (argc != 2) {  
        printf(2, "Usage: settickets <number_of_tickets>\n");
        exit();
    }
    int tickets = 0;
    char *p = argv[1];
    while (*p >= '0' && *p <= '9') {
        tickets = tickets * 10 + (*p - '0');
        p++;
    }
    if (tickets < 1) {  
        printf(2, "Error: Ticket count must be positive\n");
        exit();
    }
    if (settickets(tickets) < 0) {
        printf(2, "Error: settickets() failed\n");
        exit();
    }
    while (1) {
    }
    exit();
}
