#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "pstat.h"//定义进程统计信息结构

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

//增加或减少进程内存大小
int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

//设置当前进程票数的系统调用
int sys_settickets(void)
{
  int number;
  argint(0, &number);//从用户空间获取票数参数
  if (number < 0)
  {
    return -1; //unsuccessful
  }
  else if (number == 0)
  {
    return settickets(InitialTickets); //default//使用系统默认票数
  }
  else
  {
    return settickets(number);
  }
}

//获取系统中所有进程的状态信息，包括pid,使用状态，票数和运行时钟数
int sys_getpinfo(void)
{
  struct pstat *ps;
  if(argptr(0, (char **)&ps, sizeof(struct pstat)) < 0)
    return -1;
  getpinfo(ps);
  return 0;
}
