#include "types.h"
#include "stat.h"
#include "user.h"
int main(int argc, char *argv[])
{
    int number = atoi(argv[1]); //char->int
    settickets(number);
    while(1)
    {
        /*just for delay*/
    }
    exit();
}