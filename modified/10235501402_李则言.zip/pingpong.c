#include "user/user.h"
#include "kernel/types.h"
#include "kernel/stat.h"

int main(int argc, char *argv[]){
    int fd[2];
    if (pipe(fd) == -1) {
        fprintf(2, "Error: pipe(fd) error.\n");
    }
    if(fork()){ //parent
        char buffer[1];
        buffer[0] = 'a';
        write(fd[1], buffer, 1);
        close(fd[1]);
        read(fd[0], buffer, 1);
        fprintf(0, "%d: received pong\n", getpid());
    }
    else{ //child
        char buffer[1];
        read(fd[0], buffer, 1);
        close(fd[0]);
        fprintf(0, "%d: received ping\n", getpid());
        write(fd[1], buffer, 1);
    }
    exit(0);
}