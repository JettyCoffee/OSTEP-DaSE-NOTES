#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/param.h"

void xargs(char** part_args, int size, char* program_name){
    char buf[1024];
    char *arg[MAXARG];
    int m = 0;
    while (read(0, buf+m, 1) == 1) {
        if (m >= 1024) {
            fprintf(2, "xargs: arguments too long.\n");
            exit(1);
        }
        if (buf[m] == '\n') {
            buf[m] = '\0';
            memmove(arg, part_args, sizeof(*part_args)*size);
            int argIndex = size;
            if (argIndex == 0) {
                arg[argIndex] = program_name;
                argIndex++;
            }
            arg[argIndex] = malloc(sizeof(char)*(m+1));
            memmove(arg[argIndex], buf, m+1);
            
            arg[argIndex+1] = 0;
            if (fork() > 0) {
                wait(0);
            } 
            else if (exec(program_name, arg) == -1){
                fprintf(2, "xargs: Error exec %s\n", program_name);
            }
            free(arg[argIndex]);
            m = 0;
        } 
        else {
            m++;
        }
    }
}

int main(int argc, char* argv[])
{
    char *name = "echo";
    if (argc >= 2) {
        name = argv[1];
    } 
    else {
        fprintf(2, "xargs: too few args\n");
        exit(-1);
    }
    xargs(argv + 1, argc - 1, name);
    exit(0);
}