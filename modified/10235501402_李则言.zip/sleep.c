#include "kernel/types.h"
#include "user/user.h"

int main(int argc, char *argv[])
{
  if(argc < 2){
    fprintf(2, "使用方法: sleep [n] for sleep n seconds\n");
    exit(1);
  }
  int n = atoi(argv[1]);
  if( n <= 0) {
    fprintf(2,"sleep的参数必须是一个正整数\n");
    exit(1);
  }
  sleep(n);
  exit(0);
}