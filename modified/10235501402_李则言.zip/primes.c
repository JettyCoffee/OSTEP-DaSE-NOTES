#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void init(){ //把所有要判断的数写到管道写端
    int n;
    for(n = 2;n<=32;n++) {
        write(1, &n, sizeof n);
    }
}

void mapping (int k, int fd[2]) {
    close(k);
    dup(fd[k]);
    close(fd[0]);
    close(fd[1]);
}

void filter(int p) {
    int n;
    for(;read(0, &n, sizeof(n));) {
        if(n % p != 0) {
            write(1, &n, sizeof(n));
        }
    }
}

void prime() {
    int fd[2];
    int p;
    for(;read(0, &p, sizeof(p));) {
        fprintf(1,"prime %d\n",p);
        pipe(fd);
        if(fork()) { // 父
            mapping(0, fd);
            
        } else {  // 子
            mapping(1, fd);
            filter(p);
        }
    }
}

int main(int argc, char *argv[]) {
    int fd[2];
    if (pipe(fd) == -1) {
        fprintf(2, "Error: pipe(fd) error.\n");
    }
    if(fork()) { // 父
        mapping(0, fd);
        prime();
    } 
    else { // 子
        mapping(1, fd);
        init();
    }
    exit(0);
}