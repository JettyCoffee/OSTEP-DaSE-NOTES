#include "rand.h"


/* 采用 线性同余法
    next = next * 1103515245 + 12345
    返回值取余，限制在 0 到 RAND_MAX 范围内
*/

unsigned long next = 1;

void srand(unsigned int seed) {
    next = seed;
}

long rand(void) {
    next = next * 1103515245 + 12345;
    return (long)((next / 65536) % (RAND_MAX + 1));
}

long random_at_most(long max){    // 生成 <max 的均匀分布的随机数
    unsigned long num_bins = ( unsigned long) max + 1;
    unsigned long num_rand = ( unsigned long)RAND_MAX + 1;
    unsigned long bin_size = num_rand / num_bins;
    unsigned long tail = num_rand % num_bins;

    int x;
    do{
        x = rand();
    }while(num_rand - tail <= ( unsigned long)x);

    return x / bin_size;

}