# define RAND_MAX 32767

void srand(unsigned int seed);
long rand(void);
long random_at_most(long);