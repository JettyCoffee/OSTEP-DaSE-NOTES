#include "types.h"
#include "stat.h"
#include "user.h"
#include "pstat.h"

int main(int argc, char *argv[]){
    int count = 0;
    struct pstat s;
    getpinfo(&s);
    printf(1, "------------ Initially assigned Tickets = %d ----------", DEFAULTTICKETS);
    printf(1, "\nProcessID\tRunnable(0/1)\tTickets\t\tTicks\n");
    for (int i = 0; i < NPROC; i++){
        if(s.pid[i] && s.tickets[i] > 0){
            printf(1, "%d\t\t%d\t\t%d\t\t%d\n", s.pid[i], s.inuse[i], s.tickets[i], s.ticks[i]);
            count +=s.ticks[i];
        }
    }
    printf(1, "\n------------------- Total Ticks = %d -----------------\n", count);
    exit();
}