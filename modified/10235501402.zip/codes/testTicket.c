#include "types.h"
#include "stat.h"
#include "user.h"
#include "pstat.h"
//#include "proc.c"

int main(int argc, char *argv[]){
    int number = atoi(argv[1]);
    settickets(number);
    while(1){  
        // in order to prevent ZOMBIE state
    }
    exit();
}